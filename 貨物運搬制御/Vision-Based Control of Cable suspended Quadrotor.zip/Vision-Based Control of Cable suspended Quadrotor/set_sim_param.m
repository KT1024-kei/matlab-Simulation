clc;clear;close all;
p = paramdef();
PQini = [0 0 -1]';
qini = [0 0 1]';  